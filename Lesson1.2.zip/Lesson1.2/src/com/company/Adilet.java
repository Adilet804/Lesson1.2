package com.company;

public class Adilet {

}
